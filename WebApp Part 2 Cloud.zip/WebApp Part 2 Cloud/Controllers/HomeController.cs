
    using Azure.Data.Tables;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Configuration;
    using System.Collections.Generic;
    using System.IO;
    using System.Threading.Tasks;
    using WebApp_Part_2_Cloud.Models;

     namespace WebApp_Part_2_Cloud.Controllers
      {
        public class HomeController : Controller
        {
            private readonly IConfiguration _configuration;
            private readonly AzureBlobService _blobService;
            private readonly AzureQueueService _queueService;
            private readonly AzureFileShareService _fileShareService;

            public HomeController(IConfiguration configuration)
            {
                _configuration = configuration;
                var connectionString = _configuration.GetConnectionString("AzureStorage");
                _blobService = new AzureBlobService(connectionString);
                _queueService = new AzureQueueService(connectionString);
                _fileShareService = new AzureFileShareService(connectionString);
            }

            public IActionResult Index()
            {
                return View();
            }

            public IActionResult AboutUs()
            {
                return View();
            }

            public IActionResult ContactUs()
            {
                return View();
            }

            public IActionResult Stores()
            {
                return View();
            }

            public IActionResult SavingDeals()
            {
                return View();
            }

            public IActionResult Orders()
            {
                return View();
            }

            // Customer Profiles CRUD Operations
            public async Task<IActionResult> CustomerProfiles()
            {
                string connectionString = _configuration.GetConnectionString("AzureStorage");
                var tableClient = new TableClient(connectionString, "Customers");
                await tableClient.CreateIfNotExistsAsync();
                List<CustomerEntity> customers = new List<CustomerEntity>();
                await foreach (var customer in tableClient.QueryAsync<CustomerEntity>())
                {
                    customers.Add(customer);
                }
                return View(customers);
            }

            [HttpGet]
            public IActionResult CreateCustomer() => View();

            [HttpPost]
            public async Task<IActionResult> CreateCustomer(CustomerEntity customer)
            {
                if (ModelState.IsValid)
                {
                    string connectionString = _configuration.GetConnectionString("AzureStorage");
                    var tableClient = new TableClient(connectionString, "Customers");
                    await tableClient.CreateIfNotExistsAsync();
                    await tableClient.AddEntityAsync(customer);
                    return RedirectToAction(nameof(CustomerProfiles));
                }
                return View(customer);
            }

            [HttpGet]
            public async Task<IActionResult> EditCustomer(string id)
            {
                string connectionString = _configuration.GetConnectionString("AzureStorage");
                var tableClient = new TableClient(connectionString, "Customers");
                var customer = await tableClient.GetEntityAsync<CustomerEntity>("Customer", id);
                return View(customer.Value);
            }

            [HttpPost]
            public async Task<IActionResult> EditCustomer(CustomerEntity customer)
            {
                if (ModelState.IsValid)
                {
                    string connectionString = _configuration.GetConnectionString("AzureStorage");
                    var tableClient = new TableClient(connectionString, "Customers");
                    await tableClient.UpdateEntityAsync(customer, customer.ETag);
                    return RedirectToAction(nameof(CustomerProfiles));
                }
                return View(customer);
            }

            [HttpGet]
            public async Task<IActionResult> DeleteCustomer(string id)
            {
                string connectionString = _configuration.GetConnectionString("AzureStorage");
                var tableClient = new TableClient(connectionString, "Customers");
                await tableClient.DeleteEntityAsync("Customer", id);
                return RedirectToAction(nameof(CustomerProfiles));
            }

            // Blob Upload
            [HttpGet]
            public IActionResult UploadImage() => View();

            [HttpPost]
            public async Task<IActionResult> UploadImage(IFormFile file)
            {
                if (file != null && file.Length > 0)
                {
                    using (var stream = new MemoryStream())
                    {
                        await file.CopyToAsync(stream);
                        await _blobService.UploadBlobAsync("productimages", file.FileName, stream);
                    }
                    return RedirectToAction(nameof(Index));
                }
                return View();
            }
        }
    }

