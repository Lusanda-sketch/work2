﻿
    using Azure.Storage.Files.Shares;
    using Azure.Storage.Files.Shares.Models;
    using System.IO;
    using System.Threading.Tasks;

    namespace WebApp_Part_2_Cloud.Models
    {
        public class AzureFileShareService
        {
            private readonly ShareClient _shareClient;

            public AzureFileShareService(string connectionString)
            {
                _shareClient = new ShareClient(connectionString, "productinfo");
            }

            public async Task UploadFileAsync(string fileName, Stream fileStream)
            {
                var directoryClient = _shareClient.GetRootDirectoryClient();
                await directoryClient.CreateIfNotExistsAsync();
                var fileClient = directoryClient.GetFileClient(fileName);
                await fileClient.CreateAsync(fileStream.Length);
                await fileClient.UploadAsync(fileStream);
            }

            public async Task<Stream> DownloadFileAsync(string fileName)
            {
                var directoryClient = _shareClient.GetRootDirectoryClient();
                var fileClient = directoryClient.GetFileClient(fileName);
                var response = await fileClient.DownloadAsync();
                return response.Value.Content;
            }
        }
    }
