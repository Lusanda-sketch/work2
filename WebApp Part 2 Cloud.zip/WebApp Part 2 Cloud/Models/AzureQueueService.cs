﻿    using Azure.Storage.Queues;
    using System.Threading.Tasks;

    namespace WebApp_Part_2_Cloud.Models

{
    public class AzureQueueService
        {
            private readonly QueueServiceClient _queueServiceClient;

            public AzureQueueService(string connectionString)
            {
                _queueServiceClient = new QueueServiceClient(connectionString);
            }

            public async Task SendMessageAsync(string queueName, string message)
            {
                var queueClient = _queueServiceClient.GetQueueClient(queueName);
                await queueClient.CreateIfNotExistsAsync();
                await queueClient.SendMessageAsync(message);
            }

            public async Task<string> ReceiveMessageAsync(string queueName)
            {
                var queueClient = _queueServiceClient.GetQueueClient(queueName);
                var response = await queueClient.ReceiveMessageAsync();
                return response.Value?.MessageText;
            }
        }
    }
